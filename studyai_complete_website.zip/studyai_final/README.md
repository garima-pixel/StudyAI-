# StudyAI — Complete MVP Website

A polished, responsive Next.js website and student dashboard. It runs without Replit, Supabase, paid hosting, or an AI API.

## Run

Requires Node.js 20+.

```bash
npm install
npm run dev
```

Open http://localhost:3000

## Included

- Responsive marketing landing page
- StudyAI dashboard
- Study plan with completion tracking saved in localStorage
- AI explanation interface with demo response
- Smart quiz interface
- Progress analytics
- Pricing section
- Sign-in/profile demo
- Mobile navigation
- Security/production architecture copy

## Production connections

The UI is ready to connect to Supabase Auth/Postgres, an AI provider, and a payment gateway. API secrets must be kept server-side.

## Suggested imagery

The dashboard intentionally uses UI illustrations rather than stock photos so the product feels like a real SaaS app. If you later want lifestyle/student photography, reliable Unsplash source pages include:
- https://unsplash.com/s/photos/studying
- https://unsplash.com/s/photos/students-library
- https://unsplash.com/s/photos/online-learning
