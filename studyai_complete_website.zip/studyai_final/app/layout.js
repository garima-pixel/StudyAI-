import './globals.css';

export const metadata = {
  title: 'StudyAI — Your Personal AI Study Companion',
  description: 'Plan, learn, practice and revise with one intelligent study workspace.',
};

export default function RootLayout({ children }) {
  return <html lang="en"><body>{children}</body></html>;
}
