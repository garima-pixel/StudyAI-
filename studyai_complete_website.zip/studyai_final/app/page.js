'use client';

import { useEffect, useMemo, useState } from 'react';

const features = [
  ['🧠','AI Study Plans','Turn your subjects, deadline and available hours into a practical daily plan.'],
  ['✨','Instant Explanations','Ask about any difficult concept and get a simple explanation with examples.'],
  ['🎯','Smart Quizzes','Practice with generated questions and see which topics need more attention.'],
  ['🔁','Revision Engine','Keep weak topics in a smart queue so important ideas come back at the right time.'],
  ['📊','Progress Analytics','See study time, completion, accuracy and subject performance in one place.'],
  ['⏱️','Focus Sessions','Use short, distraction-free study sessions with clear goals and breaks.'],
];

const defaultTasks = [
  {id:1,subject:'Mathematics',topic:'Relations & Functions',minutes:35,done:true},
  {id:2,subject:'C Programming',topic:'Loops & Arrays',minutes:30,done:true},
  {id:3,subject:'English',topic:'Reading Comprehension',minutes:25,done:false},
  {id:4,subject:'Accounting',topic:'Final Accounts',minutes:40,done:false},
];

const plans = [
  {name:'Free',price:'₹0',period:'forever',desc:'Everything you need to start building a study habit.',items:['5 AI generations/day','Basic study plans','Topic explanations','10 quiz questions/day'],cta:'Start Free'},
  {name:'Student Pro',price:'₹199',period:'/ month',desc:'A complete AI study companion for everyday learning.',items:['Unlimited study plans','Unlimited explanations','Unlimited quizzes','Weak-topic analytics','Revision engine','Saved study history'],cta:'Choose Student Pro',featured:true},
  {name:'Exam Pro',price:'₹499',period:'/ 3 months',desc:'Serious preparation tools for exam season.',items:['Everything in Student Pro','Mock exams','Advanced analytics','Priority processing','Exam countdown dashboard'],cta:'Choose Exam Pro'}
];

function Button({children,onClick,secondary=false,small=false}){return <button className={(secondary?'btn secondary':'btn primary')+(small?' small':'')} onClick={onClick}>{children}</button>}

export default function Home(){
  const [view,setView]=useState('home');
  const [topic,setTopic]=useState('');
  const [answer,setAnswer]=useState('');
  const [tasks,setTasks]=useState(defaultTasks);
  const [quizTopic,setQuizTopic]=useState('');
  const [quiz,setQuiz]=useState(null);
  const [toast,setToast]=useState('');
  const [showLogin,setShowLogin]=useState(false);
  const [name,setName]=useState('Student');

  useEffect(()=>{try{const saved=localStorage.getItem('studyai_tasks'); if(saved)setTasks(JSON.parse(saved)); const n=localStorage.getItem('studyai_name'); if(n)setName(n)}catch{}},[]);
  useEffect(()=>{try{localStorage.setItem('studyai_tasks',JSON.stringify(tasks))}catch{}},[tasks]);
  useEffect(()=>{if(!toast)return;const t=setTimeout(()=>setToast(''),2500);return()=>clearTimeout(t)},[toast]);

  const completed=tasks.filter(t=>t.done).length;
  const progress=Math.round(completed/tasks.length*100);
  const studyMinutes=tasks.filter(t=>t.done).reduce((a,t)=>a+t.minutes,0)+55;

  const explain=()=>{
    if(!topic.trim()){setToast('Enter a topic first.');return}
    const clean=topic.trim();
    setAnswer(`Let’s make “${clean}” simple. Start with the core definition, connect it to one real-world example, then test yourself without looking at your notes. A strong study sequence is: understand → explain in your own words → practise → revise later. For a production version, this panel can be connected to your preferred AI API through a secure server route.`);
  };
  const makeQuiz=()=>{
    if(!quizTopic.trim()){setToast('Enter a subject or topic.');return}
    setQuiz({topic:quizTopic,questions:[
      `Which statement best describes the central idea of ${quizTopic}?`,
      `Which example would be the best application of ${quizTopic}?`,
      `What is the most important point to remember when revising ${quizTopic}?`
    ]});
  };
  const toggleTask=(id)=>setTasks(ts=>ts.map(t=>t.id===id?{...t,done:!t.done}:t));
  const scroll=(id)=>document.getElementById(id)?.scrollIntoView({behavior:'smooth'});

  if(view==='dashboard') return <Dashboard name={name} tasks={tasks} progress={progress} studyMinutes={studyMinutes} toggleTask={toggleTask} onHome={()=>setView('home')} onToast={setToast} onExplain={(t)=>{setTopic(t);setView('home');setTimeout(()=>scroll('demo'),50)}} />;

  return <main>
    <header className="nav"><button className="brand" onClick={()=>setView('home')}><span className="logo">S</span><span>Study<span>AI</span></span></button><nav><a href="#features">Features</a><a href="#how">How it works</a><a href="#pricing">Premium</a><a href="#security">Security</a></nav><div className="navActions"><button className="linkBtn" onClick={()=>setShowLogin(true)}>Sign in</button><Button small onClick={()=>setView('dashboard')}>Open Dashboard</Button></div></header>

    <section className="hero wrap"><div className="heroCopy"><div className="eyebrow pill">AI-POWERED • STUDENT-FIRST • EXAM READY</div><h1>Study smarter.<br/><em>Not longer.</em></h1><p className="lead">One intelligent workspace for planning, learning, practising and revising — designed around the way students actually study.</p><div className="heroBtns"><Button onClick={()=>scroll('demo')}>Try AI Demo <span>→</span></Button><Button secondary onClick={()=>setView('dashboard')}>Explore Dashboard</Button></div><div className="trust"><span>✓ No card required</span><span>✓ Student-friendly</span><span>✓ Private by design</span></div></div><div className="heroVisual"><div className="glow"></div><div className="dashCard"><div className="dashHead"><div><small>Good evening</small><strong>{name} 👋</strong></div><span className="miniBadge">{progress}% today</span></div><div className="progressTrack"><i style={{width:progress+'%'}}></i></div>{tasks.slice(0,3).map(t=><div className="miniTask" key={t.id}><span className={t.done?'check active':'check'}>{t.done?'✓':''}</span><div><b>{t.subject} — {t.topic}</b><small>{t.done?'Completed':`${t.minutes} min • Priority`}</small></div></div>)}<div className="insight"><b>AI insight</b><p>You’re making steady progress. Finish English next, then take a short break.</p></div></div></div></section>

    <section id="features" className="section wrap"><div className="sectionIntro"><span className="eyebrow">THE CORE PRODUCT</span><h2>Everything you need to prepare.</h2><p>StudyAI turns a pile of subjects into a clear next step.</p></div><div className="featureGrid">{features.map(([icon,title,text])=><article className="feature" key={title}><div className="featureIcon">{icon}</div><span className="featureLine"></span><h3>{title}</h3><p>{text}</p></article>)}</div></section>

    <section id="how" className="how section"><div className="wrap"><div className="sectionIntro"><span className="eyebrow">HOW IT WORKS</span><h2>From “I don’t know where to start” to a plan.</h2></div><div className="steps"><div><b>01</b><h3>Tell StudyAI your goal</h3><p>Add your subjects, exam date and available study time.</p></div><div><b>02</b><h3>Get a focused plan</h3><p>StudyAI breaks the workload into realistic sessions and priorities.</p></div><div><b>03</b><h3>Learn & practise</h3><p>Explain concepts, generate quizzes and work on weak topics.</p></div><div><b>04</b><h3>Track your progress</h3><p>See what is completed and what deserves your attention next.</p></div></div></div></section>

    <section id="demo" className="section wrap"><div className="sectionIntro"><span className="eyebrow">AI STUDY LAB</span><h2>Make any topic easier to understand.</h2><p>Try the interactive MVP now. The interface is ready for a server-side AI provider when you add your API key.</p></div><div className="lab"><div className="labInput"><div className="inputWrap"><span>⌕</span><input value={topic} onChange={e=>setTopic(e.target.value)} onKeyDown={e=>e.key==='Enter'&&explain()} placeholder="Try: Newton’s laws, binary numbers, photosynthesis..." /></div><Button onClick={explain}>Explain it</Button></div>{answer?<div className="answer"><div className="answerIcon">✦</div><div><b>StudyAI explanation</b><p>{answer}</p><div className="chips"><span>Simple definition</span><span>Example</span><span>Practice next</span></div></div></div>:<div className="labEmpty"><span>✦</span><p>Your explanation will appear here.</p></div>}</div></section>

    <section className="section wrap quizSection"><div className="quizCard"><div><span className="eyebrow">SMART QUIZZES</span><h2>Turn learning into active recall.</h2><p>Generate a quick practice set from any topic and use it to find gaps before the exam.</p></div><div className="quizBox"><input value={quizTopic} onChange={e=>setQuizTopic(e.target.value)} placeholder="Enter a topic, e.g. Accounting"/><Button onClick={makeQuiz}>Generate Quiz</Button>{quiz&&<div className="quizResult"><b>{quiz.topic} • 3-question practice</b>{quiz.questions.map((q,i)=><div className="question" key={q}><span>{i+1}</span>{q}</div>)}</div>}</div></div></section>

    <section id="pricing" className="section wrap"><div className="sectionIntro"><span className="eyebrow">PREMIUM</span><h2>Choose your study level.</h2><p>Start free. Upgrade only when you need more.</p></div><div className="priceGrid">{plans.map(p=><article className={'price '+(p.featured?'featured':'')} key={p.name}>{p.featured&&<div className="popular">MOST POPULAR</div>}<h3>{p.name}</h3><p>{p.desc}</p><div className="priceValue">{p.price}<small>{p.period}</small></div><ul>{p.items.map(x=><li key={x}><span>✓</span>{x}</li>)}</ul><Button secondary={!p.featured} onClick={()=>{if(p.name==='Free')setView('dashboard');else setToast(`${p.name} checkout is ready to connect to your payment gateway.`)}}>{p.cta}</Button></article>)}</div></section>

    <section id="security" className="section wrap"><div className="security"><div><span className="eyebrow">SECURITY BY DESIGN</span><h2>Your study data deserves care.</h2><p>StudyAI is designed so authentication, user data, AI secrets and payment status can be separated safely when you connect production services.</p></div><div className="securityGrid"><div><b>🔐 Authentication</b><p>Secure account sessions with email verification and password recovery.</p></div><div><b>🛡️ Private data</b><p>User study records can be isolated with database-level access rules.</p></div><div><b>🔑 Server secrets</b><p>AI and payment credentials should never be exposed in browser code.</p></div><div><b>🚦 Abuse controls</b><p>Validate inputs, cap requests and rate-limit expensive AI operations.</p></div></div></div></section>

    <footer><div className="brand"><span className="logo">S</span><span>Study<span>AI</span></span></div><div><span>© 2026 StudyAI</span><span>Built for better learning.</span></div></footer>
    {showLogin&&<div className="modalBack" onClick={()=>setShowLogin(false)}><div className="modal" onClick={e=>e.stopPropagation()}><button className="close" onClick={()=>setShowLogin(false)}>×</button><div className="logo bigLogo">S</div><h2>Welcome back</h2><p>Enter your name to preview your personal StudyAI dashboard.</p><input value={name} onChange={e=>setName(e.target.value)} placeholder="Your name"/><Button onClick={()=>{localStorage.setItem('studyai_name',name||'Student');setShowLogin(false);setView('dashboard')}}>Continue to StudyAI</Button><small>This MVP keeps the demo profile locally. Connect Supabase Auth for real accounts.</small></div></div>}
    {toast&&<div className="toast">{toast}</div>}
  </main>
}

function Dashboard({name,tasks,progress,studyMinutes,toggleTask,onHome,onToast,onExplain}){
  const [active,setActive]=useState('Overview');
  const [newTopic,setNewTopic]=useState('');
  const completed=tasks.filter(t=>t.done).length;
  const nav=['Overview','Study Plan','AI Explain','Quiz','Progress'];
  const startExplain=()=>{if(!newTopic.trim()){onToast('Enter a topic first.');return}onExplain(newTopic)};
  return <main className="appShell"><aside className="sidebar"><button className="brand sideBrand" onClick={onHome}><span className="logo">S</span><span>Study<span>AI</span></span></button><div className="sideNav">{nav.map(n=><button className={active===n?'sideItem active':'sideItem'} onClick={()=>setActive(n)} key={n}><span>{({Overview:'⌂','Study Plan':'✓','AI Explain':'✦',Quiz:'?','Progress':'↗'})[n]}</span>{n}</button>)}</div><div className="sideBottom"><div className="proMini"><b>Student Pro</b><span>Unlock unlimited AI tools</span><button onClick={()=>onToast('Premium checkout can be connected here.')}>View plans →</button></div><button className="backHome" onClick={onHome}>← Back to website</button></div></aside><div className="dashMain"><header className="dashHeader"><div><small>STUDY DASHBOARD</small><h1>Good morning, {name}.</h1><p>Here’s your learning snapshot for today.</p></div><div className="avatar">{(name||'S')[0].toUpperCase()}</div></header>{active==='Overview'&&<><div className="statGrid"><Stat label="Today’s progress" value={progress+'%'} note={`${completed} of ${tasks.length} tasks done`} icon="✓"/><Stat label="Study time" value={studyMinutes+'m'} note="+18m vs yesterday" icon="◷"/><Stat label="Quiz accuracy" value="82%" note="Great consistency" icon="✦"/><Stat label="Exam readiness" value="68%" note="Keep practising" icon="↗"/></div><div className="dashGrid"><section className="panel"><div className="panelHead"><div><small>TODAY’S PLAN</small><h2>Keep your momentum</h2></div><span>{completed}/{tasks.length}</span></div><div className="bigProgress"><i style={{width:progress+'%'}}></i></div>{tasks.map(t=><div className="taskRow" key={t.id} onClick={()=>toggleTask(t.id)}><span className={t.done?'check active':'check'}>{t.done?'✓':''}</span><div><b>{t.subject}</b><span>{t.topic}</span></div><em>{t.minutes} min</em></div>)}</section><section className="panel insightPanel"><small>AI STUDY COACH</small><h2>Your next best move</h2><div className="coachIcon">✦</div><p>You’ve already completed {completed} tasks. Finish <b>English — Reading Comprehension</b> next, then take a 10-minute break.</p><Button onClick={()=>setActive('AI Explain')}>Ask StudyAI</Button></section></div><section className="panel week"><div className="panelHead"><div><small>WEEKLY ACTIVITY</small><h2>Study consistency</h2></div><span>Last 7 days</span></div><div className="bars">{[32,52,45,78,62,90,72].map((h,i)=><div key={i}><i style={{height:h+'%'}}></i><span>{['M','T','W','T','F','S','S'][i]}</span></div>)}</div></section></>}
{active==='Study Plan'&&<section className="panel fullPanel"><small>STUDY PLAN</small><h2>Your personalized plan</h2><p>Complete the tasks below in order of priority. Tap a task to mark it complete.</p>{tasks.map(t=><div className="taskRow" key={t.id} onClick={()=>toggleTask(t.id)}><span className={t.done?'check active':'check'}>{t.done?'✓':''}</span><div><b>{t.subject}</b><span>{t.topic}</span></div><em>{t.minutes} min</em></div>)}</section>}
{active==='AI Explain'&&<section className="panel fullPanel"><small>AI EXPLAIN</small><h2>Make a difficult topic simple.</h2><p>Enter a topic to open the explanation experience.</p><div className="inlineForm"><input value={newTopic} onChange={e=>setNewTopic(e.target.value)} placeholder="e.g. Opportunity cost"/><Button onClick={startExplain}>Explain</Button></div><div className="featureNotice">✦ In the production build, this action connects to a server-side AI route so your secret key stays private.</div></section>}
{active==='Quiz'&&<section className="panel fullPanel"><small>SMART QUIZ</small><h2>Practice active recall.</h2><p>Choose a topic and generate a short quiz from your dashboard.</p><div className="quickChoices"><button onClick={()=>onToast('Quiz: Accounting selected')}>Accounting</button><button onClick={()=>onToast('Quiz: Mathematics selected')}>Mathematics</button><button onClick={()=>onToast('Quiz: C Programming selected')}>C Programming</button><button onClick={()=>onToast('Quiz: English selected')}>English</button></div></section>}
{active==='Progress'&&<section className="panel fullPanel"><small>PROGRESS ANALYTICS</small><h2>You’re building a strong study habit.</h2><div className="progressBig"><strong>{progress}%</strong><span>today’s plan complete</span></div><div className="subjectRows">{[['Mathematics',82],['C Programming',91],['English',64],['Accounting',58]].map(([s,v])=><div key={s}><span>{s}</span><div><i style={{width:v+'%'}}></i></div><b>{v}%</b></div>)}</div></section>}</div></main>
}
function Stat({label,value,note,icon}){return <div className="stat"><span>{icon}</span><small>{label}</small><strong>{value}</strong><p>{note}</p></div>}
